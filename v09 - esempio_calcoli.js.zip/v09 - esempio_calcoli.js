/*
 * Introduzione a Node.js
 * Programmare con variabili e operatori
 *
 * Disponibile su devACADEMY.it
 */

ricavo = 2000
console.log("L'importo della fattura = "+ricavo)
aliquota=27
tasse = ricavo * 27 /100
console.log("Tasse da pagare = "+tasse)

netto = ricavo - tasse
console.log("Importo al netto delle tasse = "+netto)
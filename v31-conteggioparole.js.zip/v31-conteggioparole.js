/*
 * Introduzione a Node.js
 * Contatore di parole
 *
 * Disponibile su devACADEMY.it
 */

testo='banana mela mela banana banana mela susina mela'

parole=testo.split(' ')

var conteggio=new Map()

parole.forEach(
	w => {
		if (conteggio.has(w)){
			valore=conteggio.get(w)
			conteggio.set(w, valore+1)
		}
		else
			conteggio.set(w, 1)
	}
)

console.log(testo)
console.log(conteggio)
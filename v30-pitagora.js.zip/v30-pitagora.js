/*
 * Introduzione a Node.js
 * Teorema di Pitagora
 *
 * Disponibile su devACADEMY.it
 */

args=process.argv

// node pitagora.js 5 4

if (args.length<4){
	console.log('Mancano argomenti')
	process.exit(-1)
}

cateto1=parseFloat(args[2])
cateto2=parseFloat(args[3])

if (isNaN(cateto1) || isNaN(cateto2)){
	console.log('Argomenti non validi')
	process.exit(-1)
}

ipotenusa=Math.sqrt(cateto1*cateto1+cateto2*cateto2)
console.log('Ipotenusa:  '+ipotenusa)
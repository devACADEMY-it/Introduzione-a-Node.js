/*
 * Introduzione a Node.js
 * Gestione dell'input utente
 *
 * Disponibile su devACADEMY.it
 */

var readline=require('readline');
var rl=readline.createInterface(process.stdin, process.stdout);

rl.setPrompt('input>  ');
rl.prompt();

rl.on('line', function(line){
	if (line.toLowerCase()==='fine')
		rl.close();
	console.log('Immesso:  '+line);
	rl.prompt();
})

rl.on('close', function(){
	console.log("Fine sessione di lavoro");
	process.exit(0);
});
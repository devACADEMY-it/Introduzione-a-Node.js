/*
 * Introduzione a Node.js
 * Schedulare operazioni a intervalli di tempo
 *
 * Disponibile su devACADEMY.it
 */

ind=1
setInterval(function(){
	ora=new Date()
	daStampare=ora.getHours()+":"+ora.getMinutes()+":"+ora.getSeconds()
	//console.log("Esecuzione #"+ind++)
	console.log(daStampare)
}, 2000)
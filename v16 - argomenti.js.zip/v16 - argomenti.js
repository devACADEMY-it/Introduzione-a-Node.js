/*
 * Introduzione a Node.js
 * Argomenti da riga di comando
 *
 * Disponibile su devACADEMY.it
 */

process.argv.forEach(
	function(val, index, array){
		console.log(index + ' : ' + val)
	}
);

console.log('\n\n')
console.log('Questo è il terzo argomento '+ process.argv[2])
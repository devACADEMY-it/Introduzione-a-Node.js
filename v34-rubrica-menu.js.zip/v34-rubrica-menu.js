/*
 * Introduzione a Node.js
 * Rubrica telefonica: menu di opzioni
 *
 * Disponibile su devACADEMY.it
 */

voci_menu=[
	'Nuova voce',
	'Stampa rubrica',
	'Ricerca',
	'Fine'
]

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')

	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)
}


// avvio dell'esecuzione
avvio()
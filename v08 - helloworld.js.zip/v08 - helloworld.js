/*
 * Introduzione a Node.js
 * Primo programma
 *
 * Disponibile su devACADEMY.it
 */

console.log("Ciao mondo!")
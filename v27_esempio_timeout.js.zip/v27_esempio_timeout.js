/*
 * Introduzione a Node.js
 * Impostazione di timeout
 *
 * Disponibile su devACADEMY.it
 */

ind=1
interval=setInterval(function(){
	console.log("Esecuzione #"+ind++)
}, 2000)

setTimeout(function(){
	clearInterval(interval)
}, 9000)
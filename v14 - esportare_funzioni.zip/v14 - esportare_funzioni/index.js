/*
 * Introduzione a Node.js
 * Esportazione di funzioni
 *
 * Disponibile su devACADEMY.it
 */

var op=require('./operazioni.js')
res=op.per(5,6)
console.log(res)
/*
 * Introduzione a Node.js
 * Esportazione di funzioni
 *
 * Disponibile su devACADEMY.it
 */

function moltiplica(a,b){
	return a*b;
}

function dividi(a,b){
	return a/b;
}

function somma(a,b){
	return a+b;
}

module.exports={
	per:moltiplica,
	diviso:dividi,
	somma

}

//exports.per=moltiplica
//exports.diviso=dividi
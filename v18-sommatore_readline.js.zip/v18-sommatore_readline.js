/*
 * Introduzione a Node.js
 * Esempio: sommatore infinito
 *
 * Disponibile su devACADEMY.it
 */

var readline=require('readline')
var input=readline.createInterface(process.stdin, process.stdout)

var somma=0

input.setPrompt('Immettere un numero>  ')
input.prompt()

input.on('line', function(riga){
	if (riga.toLowerCase()==='fine')
		input.close()
	numero=parseInt(riga)
	if (!isNaN(numero)){
		// numero è un valore numerico
		somma+=numero
		console.log("   subtotale:  "+somma)
	}
	else
		console.log("Errore: inserire solo valori numerici")
	input.prompt()
})

input.on('close', function(){
	console.log('Somma totale:  '+somma)
	process.exit(0)
})
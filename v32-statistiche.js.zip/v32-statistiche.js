/*
 * Introduzione a Node.js
 * Statistiche su un array di oggetti
 *
 * Disponibile su devACADEMY.it
 */

importi=[
{
	importo: 165.34,
	descrizione: "versamento contanti"
},
{
	importo: -250,
	descrizione: "prelievo bancomat"
},
{
	importo: -500,
	descrizione: "ricarica prepagata"
},
{
	importo: 1680,
	descrizione: "accredito stipendio"
},
{
	importo: -75,
	descrizione: "addebito bolletta"
}
]

statistiche={
	totaleAddebiti: 0,
	totaleAccrediti: 0,
	addebiti: 0,
	accrediti: 0
}

for (x of importi){
	if (x.importo<0){
		// addebito
		statistiche.totaleAddebiti+=x.importo
		statistiche.addebiti+=1
	}
	else if (x.importo>0){
		statistiche.totaleAccrediti+=x.importo
		statistiche.accrediti+=1
	}
}

console.log(statistiche)
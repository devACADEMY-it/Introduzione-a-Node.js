/*
 * Introduzione a Node.js
 * Contesto di un programma Node.js
 *
 * Disponibile su devACADEMY.it
 */

console.log(__filename)
console.log(__dirname)
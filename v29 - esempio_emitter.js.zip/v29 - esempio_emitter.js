/*
 * Introduzione a Node.js
 * Esempio: definizione di un evento
 *
 * Disponibile su devACADEMY.it
 */

var events=require('events')
var emitter=new events.EventEmitter()

emitter.on('arrivatiA10', function(){
	console.log('********** Arrivati a 10 **********')

})

ind=1
setInterval(function(){
	console.log('Siamo a '+ind++)
	if (ind==10)
		emitter.emit('arrivatiA10')
}, 2000)
/*
 * Introduzione a Node.js
 * Realizzazione di propri moduli
 *
 * Disponibile su devACADEMY.it
 */

var op=require('./operazioni.js')
res=op.moltiplica(5,6)
console.log(res)
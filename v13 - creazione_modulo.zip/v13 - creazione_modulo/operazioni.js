/*
 * Introduzione a Node.js
 * Realizzazione di propri moduli
 *
 * Disponibile su devACADEMY.it
 */

function moltiplica(a,b){
	return a*b;
}

exports.molt=moltiplica
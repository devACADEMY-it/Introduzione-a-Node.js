/*
 * Introduzione a Node.js
 * Rubrica telefonica: inserimento di un nuovo contatto
 *
 * Disponibile su devACADEMY.it
 */

var readline= require('readline')
var input=readline.createInterface(process.stdin, process.stdout)

voci_menu=[
	'Nuova voce',
	'Stampa rubrica',
	'Ricerca',
	'Fine'
]

var rubrica=[
	'Verdi Oriana 329123456',
	'Rossi Valentina 3338796443',
	'Bianchi Valerio 3290734997',
	'Neri Orazio 3478899554'
]

function inserimentoVoce(){
	input.question('Contatto:  ',
		contatto =>{
			rubrica.push(contatto)
			avvio()

		}
	)
}


function stampaRubrica(){
	console.log('\nElenco contatti:')
	rubrica.forEach(
		contatto => console.log(`* ${contatto}`)
	)
	avvio()
}

function elaboraRispostaMenu(risposta){
	switch(risposta){

		case '1':
			inserimentoVoce()
			break

		case '2':
			stampaRubrica()
			break

		case '3':
			console.log('>>>>> Cerchiamo una voce')
			break

		case '4':
			console.log('\nFine programma')
			process.exit()

		default:
			console.log('\nVoce inesistente')
			avvio()
	}
}

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')

	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)

	input.question('Scelta: ', elaboraRispostaMenu)

}


// avvio dell'esecuzione
avvio()
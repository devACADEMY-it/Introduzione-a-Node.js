/*
 * Introduzione a Node.js
 * Esempio con cicli
 *
 * Disponibile su devACADEMY.it
 */

nomi=['Alessandro', 'Ivan', 'Paola', 'Maurizio', 'Sara', 'Sabrina']

for(n of nomi){
	if (n.length>4)
	   console.log(n)
	else
	   console.log(n+" contiene meno di 5 caratteri")
}